class Aluno:
    def __init__(self, nome, ra, dt_nasc, cpf, email):
        self.nome = nome
        self.ra = ra
        self.dt_nasc = dt_nasc
        self.cpf = cpf
        self.email = email
        