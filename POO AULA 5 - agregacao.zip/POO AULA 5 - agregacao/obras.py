class Obras:
    def __init__(self, titulo, autor, ano, aluno):
        self.titulo = titulo
        self.autor = autor
        self.ano = ano
        self.aluno = aluno